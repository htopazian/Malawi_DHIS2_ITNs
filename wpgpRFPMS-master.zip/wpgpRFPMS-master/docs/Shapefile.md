# wpRFPMS : Random Forests population modelling scripts 

[![N|Solid](http://maps.worldpop.org.uk/img/worldpop-logo.png)](http://maps.worldpop.org.uk)


* [Introduction ](../README.md)
* [Dependencies and installation ](Dependencies.md)
* [Getting started ](GettingStarted.md)
* [Outputs ](Outputs.md)
* [Using Shape file ](Shapefile.md)
* [Using AdminID ](AdminID.md)

Currently documentation is not available. See comments in code for details.
